#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include "UI/Menu.hpp"
#include <algorithm>

using namespace geode::prelude;

namespace {
class ScroFloatingOrb final : public CCLayer {
    CCPoint m_touchStart{};
    CCPoint m_origin{};
    bool m_tracking = false;
    bool m_moved = false;

    bool init() override {
        if (!CCLayer::init()) return false;
#ifdef GEODE_IS_MOBILE
        constexpr float size = 64.f;
        constexpr float iconScale = 0.48f;
#else
        constexpr float size = 80.f;
        constexpr float iconScale = 0.62f;
#endif
        this->setContentSize({size, size});
        this->setAnchorPoint({0.5f, 0.5f});
        auto icon = CCSprite::create("scrobot-orb.png"_spr);
        if (!icon) return false;
        icon->setPosition({size / 2.f, size / 2.f});
        icon->setScale(iconScale);
        this->addChild(icon);
        this->setTouchEnabled(true);
        this->setTouchMode(kCCTouchesOneByOne);
        return true;
    }

    void registerWithTouchDispatcher() override {
        CCTouchDispatcher::get()->addTargetedDelegate(this, -600, true);
    }

public:
    static ScroFloatingOrb* create() {
        auto ret = new ScroFloatingOrb();
        if (ret->init()) { ret->autorelease(); return ret; }
        delete ret;
        return nullptr;
    }

    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        auto local = this->convertToNodeSpace(touch->getLocation());
        auto size = this->getContentSize();
        if (local.x < 0.f || local.y < 0.f || local.x > size.width || local.y > size.height) return false;
        m_tracking = true;
        m_moved = false;
        m_touchStart = touch->getLocation();
        m_origin = this->getPosition();
        return true;
    }

    void ccTouchMoved(CCTouch* touch, CCEvent*) override {
        if (!m_tracking || !this->getParent()) return;
        auto delta = touch->getLocation() - m_touchStart;
        if (ccpDistance(touch->getLocation(), m_touchStart) > 6.f) m_moved = true;
        if (!m_moved) return;
        auto parentSize = this->getParent()->getContentSize();
        auto size = this->getContentSize();
        float margin = size.width * 0.5f;
        auto next = m_origin + delta;
        next.x = std::clamp(next.x, margin, std::max(margin, parentSize.width - margin));
        next.y = std::clamp(next.y, margin, std::max(margin, parentSize.height - margin));
        this->setPosition(next);
    }

    void ccTouchEnded(CCTouch*, CCEvent*) override {
        if (!m_tracking) return;
        m_tracking = false;
        if (!m_moved) scro::ui::toggle();
    }

    void ccTouchCancelled(CCTouch*, CCEvent*) override {
        m_tracking = false;
        m_moved = false;
    }
};

void attachOrb(CCNode* parent) {
    if (!parent || parent->getChildByID("scrobot-floating-orb")) return;
    auto orb = ScroFloatingOrb::create();
    if (!orb) return;
    auto win = CCDirector::get()->getWinSize();
    auto size = orb->getContentSize();
    orb->setID("scrobot-floating-orb");
    orb->setPosition({win.width - size.width * 0.65f, win.height * 0.58f});
    parent->addChild(orb, 10000);
}
}

class $modify(ScroOrbMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        attachOrb(this);
        return true;
    }
};

class $modify(ScroOrbPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        attachOrb(m_uiLayer);
    }
};

class $modify(ScroOrbPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        attachOrb(this);
    }
};
