#include "UI/MacroView.hpp"
#include "Macro/Bot.hpp"
#include "Notifications/Notify.hpp"
#include "UI/Theme.hpp"
#include "Utils/Draw.hpp"
#include <algorithm>
using namespace scro;
using namespace scro::draw;

MacroView* MacroView::create(float w, bool desk, std::function<void()> onStart) {
    auto r = new MacroView();
    if (r->init() && r->setup(w, desk, std::move(onStart))) { r->autorelease(); return r; }
    delete r;
    return nullptr;
}
bool MacroView::setup(float w, bool desk, std::function<void()> onStart) {
    m_w = w; m_d = desk; m_onStart = std::move(onStart);
    m_h = desk ? 460.f : 330.f;
    this->setContentSize({w, m_h});
    rebuild();
    return true;
}

void MacroView::rebuild() {
    this->removeAllChildren();
    m_input = nullptr;
    m_names.clear();
    std::error_code ec;
    for (auto& e : std::filesystem::directory_iterator(Bot::dir(), ec))
        if (e.path().extension() == ".scro") m_names.push_back(e.path().stem().string());
    std::sort(m_names.begin(), m_names.end());

    auto& bot = Bot::get();
    bool rec = bot.state == BotState::Recording, paused = bot.recordPaused, play = bot.state == BotState::Playing;
    float mg = m_d ? 10.f : 12.f, gap = 5.f, sth = m_d ? 18.f : 22.f, bh = m_d ? 26.f : 30.f, rowH = m_d ? 20.f : 24.f;
    float fs = m_d ? 0.68f : 0.8f, inner = m_w - mg * 2, y = m_h - 4.f;
    auto ac = theme::accent();

    auto menu = CCMenu::create();
    menu->setPosition(0, 0);
    menu->setTouchPriority(-510);
    this->addChild(menu);

    // Keep this header informational only. Recording/playback labels are deliberately
    // omitted; the controls themselves show the current action.
    this->addChild(label(fmt::format("{} inputs", bot.actions.size()), fs, theme::muted(),
        {1.f, 0.5f}, {m_w - mg, y - sth / 2.f}));
    y -= sth + gap;

    float bw = (inner - gap * 2.f) / 3.f;
    auto record = CCMenuItemSpriteExtra::create(
        button(rec ? (paused ? "Resume" : "Pause") : "Record", bw, bh, rec && !paused),
        this, menu_selector(MacroView::onRecord));
    record->m_scaleMultiplier = 1.f;
    record->setPosition(mg + bw / 2.f, y - bh / 2.f);
    auto stop = CCMenuItemSpriteExtra::create(button("Stop", bw, bh), this, menu_selector(MacroView::onStop));
    stop->m_scaleMultiplier = 1.f;
    stop->setPosition(mg + bw + gap + bw / 2.f, y - bh / 2.f);
    stop->setEnabled(rec || play);
    auto playButton = CCMenuItemSpriteExtra::create(
        button(play ? "Stop Play" : "Play", bw, bh, play), this, menu_selector(MacroView::onPlay));
    playButton->m_scaleMultiplier = 1.f;
    playButton->setPosition(mg + (bw + gap) * 2.f + bw / 2.f, y - bh / 2.f);
    menu->addChild(record); menu->addChild(stop); menu->addChild(playButton);
    y -= bh + gap;

    // name + Save
    float sw = m_d ? 36.f : 50.f, iw = inner - sw - gap;
    m_input = TextInput::create(iw, "Name", "chatFont.fnt");
    m_input->setFilter("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-");
    m_input->setString(m_sel >= 0 && m_sel < static_cast<int>(m_names.size()) ? m_names[m_sel] : "macro1");
    m_input->setPosition(mg + iw / 2, y - bh / 2);
    this->addChild(m_input);
    auto sv = CCMenuItemSpriteExtra::create(button("Save", sw, bh), this, menu_selector(MacroView::onSave));
    sv->m_scaleMultiplier = 1.f; sv->setPosition(m_w - mg - sw / 2, y - bh / 2);
    menu->addChild(sv);
    y -= bh + gap;

    // saved macros (3 per page)
    constexpr int perPage = 2;
    int pages = std::max(1, static_cast<int>((m_names.size() + perPage - 1) / perPage));
    m_page = std::min(m_page, pages - 1);
    if (m_names.empty()) this->addChild(label("No saved macros", fs, theme::muted(), {0.5f, 0.5f}, {m_w / 2, y - rowH * 1.5f}));
    for (int i = 0; i < perPage; i++) {
        int idx = m_page * perPage + i;
        if (idx >= static_cast<int>(m_names.size())) break;
        bool sel = idx == m_sel;
        auto n = CCNode::create();
        n->setContentSize({inner, rowH});
        n->addChild(rect(inner, rowH, sel ? ccc4(26, 26, 28, 255) : ccc4(19, 19, 21, 255)));
        auto sb = rect(2, rowH * 0.6f, sel ? ccc4(ac.r, ac.g, ac.b, 255) : ccc4(60, 60, 64, 255));
        sb->setPosition(4, rowH * 0.2f);
        n->addChild(sb);
        n->addChild(label(m_names[idx], fs, theme::text(), {0.f, 0.5f}, {12, rowH / 2}));
        auto it = CCMenuItemSpriteExtra::create(n, this, menu_selector(MacroView::onPick));
        it->m_scaleMultiplier = 1.f; it->setTag(idx);
        it->setPosition(m_w / 2, y - rowH / 2 - i * (rowH + 2));
        menu->addChild(it);
    }
    y -= perPage * (rowH + 2) + gap;
    if (pages > 1) {
        auto pv = CCMenuItemSpriteExtra::create(button("<", 22, 14), this, menu_selector(MacroView::onPage));
        pv->setTag(-1); pv->setPosition(m_w - mg - 11 - 52, y - 7);
        auto nx = CCMenuItemSpriteExtra::create(button(">", 22, 14), this, menu_selector(MacroView::onPage));
        nx->setTag(1); nx->setPosition(m_w - mg - 11, y - 7);
        menu->addChild(pv); menu->addChild(nx);
        this->addChild(label(fmt::format("{}/{}", m_page + 1, pages), fs, theme::muted(), {0.5f, 0.5f}, {m_w - mg - 32, y - 7}));
    }

    // Small non-destructive input editor: inspect, step through, remove one input,
    // or clear the loaded macro. It is disabled while capture/playback is active.
    auto const count = bot.actions.size();
    if (count) m_actionSel = std::min(m_actionSel, static_cast<int>(count - 1));
    else m_actionSel = 0;
    y -= 20.f;
    this->addChild(label("INPUT EDITOR", fs * 0.9f, ac, {0.f, 0.5f}, {mg, y}));
    std::string detail = "No inputs loaded";
    if (count) {
        auto const& a = bot.actions[static_cast<size_t>(m_actionSel)];
        detail = fmt::format("{}/{}   FRAME {}   P{}   {}", m_actionSel + 1, count, a.frame,
            a.p1 ? 1 : 2, a.down ? "PRESS" : "RELEASE");
    }
    auto detailLabel = label(detail, fs * 0.82f, theme::muted(), {1.f, 0.5f}, {m_w - mg, y});
    fit(detailLabel, inner * 0.72f, fs * 0.82f);
    this->addChild(detailLabel);

    float editGap = 3.f;
    float editW = (inner - editGap * 2.f) / 3.f;
    const bool editing = bot.state == BotState::Idle && count > 0;
    auto addEdit = [&](char const* text, int tag, int slot, int row, bool enabled) {
        auto item = CCMenuItemSpriteExtra::create(button(text, editW, m_d ? 18.f : 21.f),
            this, menu_selector(MacroView::onEditAction));
        item->m_scaleMultiplier = 1.f; item->setTag(tag); item->setEnabled(enabled);
        float editY = y - (m_d ? 16.f : 18.f) - row * (m_d ? 20.f : 23.f);
        item->setPosition(mg + editW / 2.f + slot * (editW + editGap), editY);
        menu->addChild(item);
    };
    addEdit("PREV", -1, 0, 0, editing && m_actionSel > 0);
    addEdit("NEXT", 1, 1, 0, editing && count > 0 && m_actionSel + 1 < static_cast<int>(count));
    addEdit("DELETE", -2, 2, 0, editing);
    addEdit("-1 FRAME", -4, 0, 1, editing);
    addEdit("+1 FRAME", 4, 1, 1, editing);
    addEdit("CLEAR", -3, 2, 1, editing);
}

void MacroView::begin(int st) {
    auto& b = Bot::get();
    auto state = static_cast<BotState>(st);
    if (b.state == state) {
        b.state = BotState::Idle;
        b.recordPaused = false;
        b.injecting = false;
        runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
        return;
    }
    PauseLayer* pause = nullptr;
    if (auto scene = CCDirector::get()->getRunningScene())
        pause = scene->getChildByType<PauseLayer>(0);

    // Never restart the level when a macro starts: restart clears practice checkpoints.
    if (state == BotState::Recording) {
        b.assistedRun = false;
        b.recordPaused = false;
        b.actions.clear();
        b.index = 0;
    } else if (state == BotState::Playing) {
        b.assistedRun = true;
        b.recordPaused = false;
        b.seek(PlayLayer::get() ? PlayLayer::get()->m_gameState.m_currentProgress : 0);
    }
    b.state = state;
    if (m_onStart) m_onStart();
    if (pause) pause->onResume(nullptr);
    runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}
void MacroView::onRecord(CCObject*) {
    auto& bot = Bot::get();
    if (bot.state == BotState::Recording) {
        bot.recordPaused = !bot.recordPaused;
        runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
        return;
    }
    begin(static_cast<int>(BotState::Recording));
}
void MacroView::onStop(CCObject*) {
    auto& bot = Bot::get();
    bot.state = BotState::Idle;
    bot.recordPaused = false;
    bot.injecting = false;
    runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}
void MacroView::onPlay(CCObject*) {
    auto& bot = Bot::get();
    if (bot.state == BotState::Playing) { begin(static_cast<int>(BotState::Playing)); return; }
    if (bot.actions.empty()) return notify("Load a macro first", false);
    FLAlertLayer::create(this, "Macro Playback Warning", "Cancel", "Continue",
        "Macros are for fun, practice, testing and level showcases. This run will be marked macro-assisted, and completion progress will be restricted where the game supports it. Do not present it as a legitimate completion.", 320.f)->show();
}
void MacroView::FLAlert_Clicked(FLAlertLayer*, bool btn2) {
    if (btn2 && !Bot::get().actions.empty()) begin(static_cast<int>(BotState::Playing));
}
void MacroView::onSave(CCObject*) {
    bool ok = m_input && Bot::get().save(m_input->getString());
    notify(ok ? "Macro saved" : "Nothing to save", ok);
    if (ok) runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}
void MacroView::onPick(CCObject* s) {
    int idx = static_cast<CCNode*>(s)->getTag();
    if (idx < 0 || idx >= static_cast<int>(m_names.size())) return;
    bool ok = Bot::get().load(m_names[idx]);
    m_sel = idx;
    m_actionSel = 0;
    notify(ok ? "Macro loaded" : "Invalid macro file", ok);
    runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}
void MacroView::onPage(CCObject* s) {
    m_page = std::max(0, m_page + static_cast<CCNode*>(s)->getTag());
    runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}

void MacroView::onEditAction(CCObject* sender) {
    auto& bot = Bot::get();
    if (bot.state != BotState::Idle) return;
    int tag = static_cast<CCNode*>(sender)->getTag();
    if (tag == -3) {
        bot.actions.clear();
        m_actionSel = 0;
        notify("Macro inputs cleared");
    } else if (tag == -2) {
        if (m_actionSel >= 0 && m_actionSel < static_cast<int>(bot.actions.size())) {
            bot.actions.erase(bot.actions.begin() + m_actionSel);
            m_actionSel = std::clamp(m_actionSel, 0, std::max(0, static_cast<int>(bot.actions.size()) - 1));
            notify("Input removed");
        }
    } else if (tag == -1) {
        m_actionSel = std::max(0, m_actionSel - 1);
    } else if (tag == 1) {
        m_actionSel = std::min(std::max(0, static_cast<int>(bot.actions.size()) - 1), m_actionSel + 1);
    } else if (tag == -4 || tag == 4) {
        if (m_actionSel >= 0 && m_actionSel < static_cast<int>(bot.actions.size())) {
            auto& action = bot.actions[static_cast<size_t>(m_actionSel)];
            action.frame = std::max(0, action.frame + (tag < 0 ? -1 : 1));
            std::stable_sort(bot.actions.begin(), bot.actions.end(), [](Action const& a, Action const& b) {
                return a.frame < b.frame;
            });
        }
    }
    runAction(CCCallFunc::create(this, callfunc_selector(MacroView::rebuild)));
}
