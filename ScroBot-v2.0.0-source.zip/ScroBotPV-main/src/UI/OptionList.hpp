#pragma once
#include "Utils/Settings.hpp"
#include <Geode/Geode.hpp>
#include <functional>
#include <string>
#include <vector>
using namespace geode::prelude;

namespace scro {
class OptionList : public CCNode {
    float m_w = 0.f, m_h = 0.f, m_availH = 0.f;
    int m_page = 0, m_pageCount = 1;
    std::string m_category;
    std::vector<Option*> m_opts;
    std::vector<TextInput*> m_inputs;
    std::function<void(Option*)> m_onSel;
    bool setup(std::string const& cat, float w, float availH, bool animate,
        std::function<void(Option*)> onSel);
    void applyStepValue(int index, float value, bool persist);
public:
    static OptionList* create(std::string const& cat, float w, float availH,
        bool animate, std::function<void(Option*)> onSel);
    float height() const { return m_h; }
    void onToggle(CCObject*);
    void onStep(CCObject*);
    void onSetValue(CCObject*);
    void onAction(CCObject*);
    void onHelp(CCObject*);
    void onPage(CCObject*);
    void rebuild() {
        this->removeAllChildrenWithCleanup(true);
        setup(m_category, m_w, m_availH, false, m_onSel);
    }
};
}
