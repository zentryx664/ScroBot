#pragma once
#include <Geode/Geode.hpp>
using namespace geode::prelude;

// Auto uses a light violet desktop palette and a charcoal mobile palette.
namespace scro::theme {
inline std::string selected() { return Mod::get()->getSettingValue<std::string>("ui-theme"); }
inline bool dark() {
    auto choice = selected();
    if (choice == "Dark") return true;
    if (choice == "Light") return false;
#ifdef GEODE_IS_MOBILE
    return true;
#else
    return false;
#endif
}
inline ccColor3B panel()       { return dark() ? ccColor3B{24, 23, 29} : ccColor3B{245, 241, 251}; }
inline ccColor3B surface()     { return dark() ? ccColor3B{37, 35, 44} : ccColor3B{255, 253, 255}; }
inline ccColor3B accent()      { return dark() ? ccColor3B{151, 91, 220} : ccColor3B{132, 76, 196}; }
inline ccColor3B text()        { return dark() ? ccColor3B{245, 243, 249} : ccColor3B{34, 29, 42}; }
inline ccColor3B muted()       { return dark() ? ccColor3B{177, 171, 188} : ccColor3B{104, 95, 116}; }
inline ccColor3B selectedText(){ return {255, 255, 255}; }
inline char const* font() { return "chatFont.fnt"; }
inline float fontScale() { return 1.f; }
}

namespace scro::metrics {
#ifdef GEODE_IS_MOBILE
inline constexpr float rowH = 36.f, stepH = 64.f, navH = 28.f;
inline constexpr float toggleScale = 0.76f, nameScale = 0.88f, valueScale = 0.82f;
inline constexpr float actionW = 82.f, actionH = 28.f;
inline constexpr float pageBtnW = 32.f, pageBtnH = 24.f;
inline constexpr float tabH = 38.f, tabText = 0.78f;
inline constexpr float footW = 84.f, footH = 34.f;
inline constexpr float hudBtn = 40.f, pauseBtnW = 68.f, pauseBtnH = 32.f;
#else
inline constexpr float rowH = 32.f, stepH = 60.f, navH = 26.f;
inline constexpr float toggleScale = 0.68f, nameScale = 0.88f, valueScale = 0.80f;
inline constexpr float actionW = 76.f, actionH = 25.f;
inline constexpr float pageBtnW = 28.f, pageBtnH = 21.f;
inline constexpr float tabH = 42.f, tabText = 0.76f;
inline constexpr float footW = 82.f, footH = 30.f;
inline constexpr float hudBtn = 38.f, pauseBtnW = 64.f, pauseBtnH = 29.f;
#endif
}
