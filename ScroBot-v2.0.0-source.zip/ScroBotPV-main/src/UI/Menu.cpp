#include "UI/MacroView.hpp"
#include "UI/Menu.hpp"
#include "UI/OptionList.hpp"
#include "UI/Theme.hpp"
#include "Notifications/Notify.hpp"
#include "Utils/Draw.hpp"
#include <algorithm>
#include <string>
using namespace scro;
using namespace scro::draw;

namespace {
#ifdef GEODE_IS_MOBILE
static constexpr float W = 920.f, H = 520.f;
static constexpr float HEAD = 46.f, NAV = 44.f, FOOT = 46.f;
#else
static constexpr float W = 1100.f, H = 660.f;
static constexpr float HEAD = 52.f, NAV = 48.f, FOOT = 48.f;
#endif
static constexpr float PAD = 16.f;
static constexpr float CONTENT_W = W - PAD * 2.f;
static constexpr float CONTENT_H = H - HEAD - NAV - FOOT - 28.f;

class ScroDragBar final : public CCLayer {
    CCNode* m_target = nullptr;
    CCPoint m_start{};
    CCPoint m_origin{};
    bool m_dragging = false;

    bool init(CCNode* target, float w, float h) {
        if (!CCLayer::init()) return false;
        m_target = target;
        setContentSize({w, h});
        setTouchEnabled(true);
        setTouchMode(kCCTouchesOneByOne);
        return true;
    }
    void registerWithTouchDispatcher() override {
        CCTouchDispatcher::get()->addTargetedDelegate(this, -540, true);
    }
public:
    static ScroDragBar* create(CCNode* target, float w, float h) {
        auto ret = new ScroDragBar();
        if (ret->init(target, w, h)) { ret->autorelease(); return ret; }
        delete ret;
        return nullptr;
    }
    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        auto p = convertToNodeSpace(touch->getLocation());
        if (p.x < 0.f || p.y < 0.f || p.x > getContentSize().width || p.y > getContentSize().height)
            return false;
        m_dragging = true;
        m_start = touch->getLocation();
        m_origin = m_target->getPosition();
        return true;
    }
    void ccTouchMoved(CCTouch* touch, CCEvent*) override {
        if (!m_dragging || !m_target) return;
        auto next = m_origin + (touch->getLocation() - m_start);
        auto win = CCDirector::get()->getWinSize();
        float halfW = m_target->getContentSize().width * m_target->getScale() * 0.5f;
        float halfH = m_target->getContentSize().height * m_target->getScale() * 0.5f;
        next.x = std::clamp(next.x, halfW, win.width - halfW);
        next.y = std::clamp(next.y, halfH, win.height - halfH);
        m_target->setPosition(next);
    }
    void ccTouchEnded(CCTouch*, CCEvent*) override { m_dragging = false; }
    void ccTouchCancelled(CCTouch*, CCEvent*) override { m_dragging = false; }
};

class ScroMenu final : public FLAlertLayer {
    CCNode* m_root = nullptr;
    CCNode* m_pane = nullptr;
    CCLabelBMFont* m_title = nullptr;
    CCLabelBMFont* m_desc = nullptr;
    std::vector<CCMenuItemSpriteExtra*> m_tabs;
    int m_tab = 0;
    bool m_closing = false;
    float m_layoutScale = 1.f;

    CCMenu* newMenu(CCNode* parent) {
        auto menu = CCMenu::create();
        menu->setPosition(0.f, 0.f);
        menu->setTouchPriority(-510);
        parent->addChild(menu);
        return menu;
    }

    CCNode* tabButton(int index, bool selected) {
        return button(kCategories[index], 0.f + tabWidth(), metrics::tabH, selected, metrics::tabText);
    }

    float tabWidth() const {
        constexpr float gap = 5.f;
        return (W - PAD * 2.f - gap * (kNumCategories - 1)) / kNumCategories;
    }

    bool init() override {
        if (!FLAlertLayer::init(120)) return false;
        m_noElasticity = true;
        m_mainLayer = CCLayer::create();
        addChild(m_mainLayer);
        setKeypadEnabled(true);
        setTouchEnabled(true);

        auto win = CCDirector::get()->getWinSize();
        const float sx = (win.width - 12.f) / W;
        const float sy = (win.height - 12.f) / H;
        m_layoutScale = std::clamp(std::min({1.f, sx, sy}), 0.42f, 1.f);
        m_root = CCNode::create();
        m_root->setContentSize({W, H});
        m_root->setAnchorPoint({0.5f, 0.5f});
        m_root->setPosition(win.width / 2.f, win.height / 2.f);
        m_mainLayer->addChild(m_root);

        m_root->addChild(panel(W, H, true));
        auto header = inset(W - 2.f, HEAD - 2.f);
        header->setPosition(1.f, H - HEAD - 1.f);
        header->setColor(theme::accent());
        m_root->addChild(header);

        m_title = label("ScroBot 2.0.0", 1.15f, theme::selectedText(),
            {0.5f, 0.5f}, {W / 2.f, H - HEAD / 2.f});
        fit(m_title, W - 100.f, 1.15f);
        m_root->addChild(m_title);

        // The title bar is draggable on both desktop and mobile. No window chrome
        // or extra close/minimize controls are shown; Back / Tab+W closes the menu.
        auto drag = ScroDragBar::create(m_root, W - 20.f, HEAD - 4.f);
        drag->setPosition(10.f, H - HEAD + 2.f);
        m_root->addChild(drag, 30);

        auto navMenu = newMenu(m_root);
        const float gap = 5.f;
        const float width = tabWidth();
        const float navY = H - HEAD - NAV / 2.f - 5.f;
        for (int i = 0; i < kNumCategories; ++i) {
            auto item = CCMenuItemSpriteExtra::create(tabButton(i, i == 0), this,
                menu_selector(ScroMenu::onTab));
            item->m_scaleMultiplier = 1.f;
            item->setTag(i);
            item->setPosition(PAD + width / 2.f + i * (width + gap), navY);
            navMenu->addChild(item);
            m_tabs.push_back(item);
        }

        auto contentBg = inset(CONTENT_W, CONTENT_H + 10.f);
        contentBg->setPosition(PAD, FOOT + 8.f);
        m_root->addChild(contentBg);

        m_desc = label("Select an option to view its description", 0.72f, theme::muted(),
            {0.f, 0.5f}, {PAD + 2.f, FOOT / 2.f});
        m_root->addChild(m_desc);

        auto footerMenu = newMenu(m_root);
        auto resetButton = CCMenuItemSpriteExtra::create(
            button("Reset", metrics::footW, metrics::footH), this, menu_selector(ScroMenu::onReset));
        resetButton->m_scaleMultiplier = 1.f;
        resetButton->setPosition(W - PAD - metrics::footW * 1.5f - 6.f, FOOT / 2.f);
        footerMenu->addChild(resetButton);
        auto saveButton = CCMenuItemSpriteExtra::create(
            button("Save", metrics::footW, metrics::footH, true), this, menu_selector(ScroMenu::onSave));
        saveButton->m_scaleMultiplier = 1.f;
        saveButton->setPosition(W - PAD - metrics::footW / 2.f, FOOT / 2.f);
        footerMenu->addChild(saveButton);

        showTab(0, false);
        m_root->setScale(m_layoutScale * 0.97f);
        m_root->runAction(CCEaseExponentialOut::create(CCScaleTo::create(0.16f, m_layoutScale)));
        return true;
    }

    void setDesc(Option* option) {
        std::string text = option ? (option->desc.empty() ? option->name : option->desc)
                                  : "Select an option to view its description";
        m_desc->setString(text.c_str());
        fit(m_desc, W - metrics::footW * 2.f - 90.f, 0.72f);
    }

    void showTab(int index, bool animate) {
        if (index < 0 || index >= kNumCategories) return;
        m_tab = index;
        for (int i = 0; i < kNumCategories; ++i)
            m_tabs[static_cast<size_t>(i)]->setNormalImage(tabButton(i, i == index));

        m_title->setString(fmt::format("ScroBot 2.0.0  /  {}", kCategories[index]).c_str());
        fit(m_title, W - 100.f, 1.15f);

        if (m_pane) {
            auto old = m_pane;
            old->setVisible(false);
            old->runAction(CCSequence::create(CCDelayTime::create(0.f),
                CCCallFunc::create(old, callfunc_selector(CCNode::removeFromParent)), nullptr));
            m_pane = nullptr;
        }

        const float paneW = CONTENT_W - 20.f;
        const float paneH = CONTENT_H - 12.f;
        const std::string category = kCategories[index];
        CCNode* pane = nullptr;
#ifdef GEODE_IS_MOBILE
        constexpr bool desktop = false;
#else
        constexpr bool desktop = true;
#endif
        if (category == "Replay") {
            // Keep the macro controls open while recording so Pause/Resume remains reachable.
            auto macro = MacroView::create(paneW, desktop, [] {});
            pane = macro;
        } else {
            pane = OptionList::create(category, paneW, paneH, animate,
                [this](Option* option) { setDesc(option); });
        }
        if (!pane) {
            setDesc(nullptr);
            return;
        }
        const float paneHActual = category == "Replay" ? pane->getContentSize().height : paneH;
        pane->setPosition(PAD + 10.f, FOOT + 13.f + std::max(0.f, (paneH - paneHActual) / 2.f));
        m_root->addChild(pane, 5);
        m_pane = pane;
        setDesc(nullptr);
        if (animate) {
            pane->setPositionX(pane->getPositionX() + 8.f);
            fadeTree(pane, 0.f);
            pane->runAction(CCEaseOut::create(CCMoveBy::create(0.12f, {-8.f, 0.f}), 2.f));
        }
    }

    void onTab(CCObject* sender) {
        const int index = static_cast<CCNode*>(sender)->getTag();
        if (!m_closing && index != m_tab) showTab(index, true);
    }
    void onReset(CCObject*) {
        if (std::string(kCategories[m_tab]) == "Replay") return;
        if (m_tab == 0) {
            for (int i = 0; i < kNumCategories; ++i) reset(kCategories[i]);
        } else {
            reset(kCategories[m_tab]);
        }
        changed();
        showTab(m_tab, false);
        notify(m_tab == 0 ? "All settings reset" : "Category reset");
    }
    void onSave(CCObject*) { save(); notify("Settings saved"); }
    void finish() {
        setKeypadEnabled(false);
        setTouchEnabled(false);
        removeFromParentAndCleanup(true);
    }
    void keyBackClicked() override { close(); }

public:
    void close() {
        if (m_closing) return;
        m_closing = true;
        m_root->runAction(CCSequence::create(CCEaseIn::create(CCScaleTo::create(0.12f, m_layoutScale * 0.97f), 2.f),
            CCDelayTime::create(0.02f), CCCallFunc::create(this, callfunc_selector(ScroMenu::finish)), nullptr));
    }
    static ScroMenu* create() {
        auto ret = new ScroMenu();
        if (ret->init()) { ret->autorelease(); return ret; }
        delete ret;
        return nullptr;
    }
};
}

void scro::ui::open() {
    auto scene = CCDirector::get()->getRunningScene();
    if (!scene || scene->getChildByID("scrobot-menu")) return;
    if (auto menu = ScroMenu::create()) {
        menu->setID("scrobot-menu");
        menu->show();
    }
}

void scro::ui::toggle() {
    auto scene = CCDirector::get()->getRunningScene();
    if (!scene) return;
    if (auto menu = scene->getChildByID("scrobot-menu"))
        static_cast<ScroMenu*>(menu)->close();
    else
        open();
}
