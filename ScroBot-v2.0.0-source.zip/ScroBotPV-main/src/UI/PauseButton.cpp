#include <Geode/Geode.hpp>
// The ScroBot v2 menu entry is provided by the floating control.
