#include "UI/OptionList.hpp"
#include "UI/Theme.hpp"
#include "Utils/Draw.hpp"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>
#include <utility>
#include <limits>
#include <stdexcept>
using namespace scro;
using namespace scro::draw;

namespace {
std::string editableValue(Option const& option) {
    if (!option.names.empty()) {
        int i = std::clamp(static_cast<int>(std::lround(option.f)), 0,
            static_cast<int>(option.names.size()) - 1);
        const auto& name = option.names[static_cast<size_t>(i)];
        char* end = nullptr;
        float numeric = std::strtof(name.c_str(), &end);
        if (end != name.c_str() && std::isfinite(numeric)) return fmt::format("{:.0f}", numeric);
        return name;
    }
    if (option.st < 1.f || option.unit == "x") return fmt::format("{:.2f}", option.f);
    return fmt::format("{:.0f}", option.f);
}

float normalizeValue(Option const& option, float input) {
    if (!option.names.empty()) {
        float best = option.mn;
        float bestDistance = std::numeric_limits<float>::max();
        for (size_t i = 0; i < option.names.size(); ++i) {
            char* end = nullptr;
            float candidate = std::strtof(option.names[i].c_str(), &end);
            if (end == option.names[i].c_str() || !std::isfinite(candidate)) continue;
            float distance = std::fabs(candidate - input);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = static_cast<float>(i);
            }
        }
        return best;
    }
    float value = std::clamp(input, option.mn, option.mx);
    if (option.st > 0.f) value = option.mn + std::round((value - option.mn) / option.st) * option.st;
    return std::clamp(value, option.mn, option.mx);
}

// Lightweight touch slider. It only edits the Option passed by OptionList and
// does not intercept touches outside its own horizontal track.
class OptionSlider final : public CCLayer {
    float m_min = 0.f, m_max = 1.f, m_step = 0.01f;
    float m_value = 0.f;
    CCLayerColor* m_fill = nullptr;
    CCLayerColor* m_thumb = nullptr;
    std::function<void(float, bool)> m_changed;
    bool m_dragging = false;

    void updateFromTouch(CCTouch* touch, bool final) {
        auto p = convertToNodeSpace(touch->getLocation());
        float width = std::max(1.f, getContentSize().width - 14.f);
        float ratio = std::clamp((p.x - 7.f) / width, 0.f, 1.f);
        float raw = m_min + ratio * (m_max - m_min);
        if (m_step > 0.f) raw = m_min + std::round((raw - m_min) / m_step) * m_step;
        m_value = std::clamp(raw, m_min, m_max);
        updateVisuals();
        if (m_changed) m_changed(m_value, final);
    }

    void updateVisuals() {
        float width = std::max(1.f, getContentSize().width - 14.f);
        float ratio = m_max > m_min ? (m_value - m_min) / (m_max - m_min) : 0.f;
        float filled = width * std::clamp(ratio, 0.f, 1.f);
        m_fill->setContentSize({std::max(1.f, filled), 4.f});
        m_thumb->setPosition({7.f + filled - 6.f, 10.f});
    }

    bool init(float w, float h, float mn, float mx, float step, float value,
        std::function<void(float, bool)> callback) {
        if (!CCLayer::init()) return false;
        m_min = mn; m_max = std::max(mn + 0.0001f, mx); m_step = step;
        m_value = std::clamp(value, m_min, m_max);
        m_changed = std::move(callback);
        setContentSize({w, h});
        setTouchEnabled(true);
        setTouchMode(kCCTouchesOneByOne);
        auto track = rect(std::max(1.f, w - 14.f), 4.f, ccc4(
#ifdef GEODE_IS_MOBILE
            86, 82, 99, 255
#else
            205, 194, 218, 255
#endif
        ));
        track->setPosition(7.f, 10.f);
        addChild(track);
        m_fill = rect(1.f, 4.f, ccc4(theme::accent().r, theme::accent().g, theme::accent().b, 255));
        m_fill->setPosition(7.f, 10.f);
        addChild(m_fill);
        m_thumb = rect(12.f, 14.f, ccc4(theme::accent().r, theme::accent().g, theme::accent().b, 255));
        addChild(m_thumb);
        updateVisuals();
        return true;
    }

    void registerWithTouchDispatcher() override {
        CCTouchDispatcher::get()->addTargetedDelegate(this, -530, true);
    }
public:
    static OptionSlider* create(float w, float h, float mn, float mx, float step,
        float value, std::function<void(float, bool)> callback) {
        auto ret = new OptionSlider();
        if (ret->init(w, h, mn, mx, step, value, std::move(callback))) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
    void setValue(float value) {
        m_value = std::clamp(value, m_min, m_max);
        updateVisuals();
    }
    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        auto p = convertToNodeSpace(touch->getLocation());
        if (p.x < 0.f || p.y < -4.f || p.x > getContentSize().width || p.y > getContentSize().height + 4.f)
            return false;
        m_dragging = true;
        updateFromTouch(touch, false);
        return true;
    }
    void ccTouchMoved(CCTouch* touch, CCEvent*) override {
        if (m_dragging) updateFromTouch(touch, false);
    }
    void ccTouchEnded(CCTouch* touch, CCEvent*) override {
        if (!m_dragging) return;
        updateFromTouch(touch, true);
        m_dragging = false;
    }
    void ccTouchCancelled(CCTouch*, CCEvent*) override { m_dragging = false; }
};
}

OptionList* OptionList::create(std::string const& cat, float w, float availH,
    bool animate, std::function<void(Option*)> onSel) {
    auto ret = new OptionList();
    if (ret->init() && ret->setup(cat, w, availH, animate, std::move(onSel))) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool OptionList::setup(std::string const& cat, float w, float availH, bool animate,
    std::function<void(Option*)> onSel) {
    m_w = w;
    m_h = m_availH = availH;
    m_category = cat;
    m_onSel = std::move(onSel);
    m_opts = cat == "Global" ? allOptions() : inCategory(cat);
    m_inputs.assign(m_opts.size(), nullptr);
    setContentSize({w, availH});

    if (m_opts.empty()) {
        addChild(label("No options available", 0.82f, theme::muted(), {0.5f, 0.5f}, {w / 2.f, availH / 2.f}));
        return true;
    }

#ifdef GEODE_IS_MOBILE
    constexpr int columns = 3;
    constexpr int rowsPerColumn = 6;
    constexpr float outerGap = 7.f, innerGap = 5.f, bottomSpace = 34.f;
#else
    constexpr int columns = 5;
    constexpr int rowsPerColumn = 10;
    constexpr float outerGap = 8.f, innerGap = 7.f, bottomSpace = 32.f;
#endif
    const float contentH = std::max(metrics::stepH, availH - bottomSpace - 8.f);
    const size_t perPage = static_cast<size_t>(rowsPerColumn * columns);
    m_pageCount = std::max(1, static_cast<int>((m_opts.size() + perPage - 1) / perPage));
    m_page = std::clamp(m_page, 0, m_pageCount - 1);
    const size_t pageStart = static_cast<size_t>(m_page) * perPage;

    auto menu = CCMenu::create();
    menu->setPosition(0.f, 0.f);
    menu->setTouchPriority(-510);
    addChild(menu, 10);

    const float colW = (w - outerGap * 2.f - innerGap * (columns - 1)) / columns;
    const float colH = contentH;
    const float topY = availH - 5.f;

    for (int col = 0; col < columns; ++col) {
        const size_t first = pageStart + static_cast<size_t>(col * rowsPerColumn);
        if (first >= m_opts.size()) break;
        const size_t last = std::min(m_opts.size(), first + static_cast<size_t>(rowsPerColumn));
        const float x = outerGap + col * (colW + innerGap);
        auto columnBg = rect(colW, colH, ccc4(theme::surface().r, theme::surface().g, theme::surface().b, 255));
        columnBg->setPosition(x, topY - colH);
        addChild(columnBg);

        float y = topY - 9.f;
        for (size_t i = first; i < last; ++i) {
            Option* option = m_opts[i];
            const int index = static_cast<int>(i);
            if (option->kind == Kind::Step) {
                const float rowH = metrics::stepH;
                y -= rowH;
                auto title = label(option->name, metrics::nameScale, theme::text(), {0.f, 0.5f}, {x + 9.f, y + rowH - 13.f});
                fit(title, colW - 18.f, metrics::nameScale);
                addChild(title);

                const float fieldW = 54.f;
                const float applyW = 29.f;
                const float sliderW = std::max(44.f, colW - fieldW - applyW - 34.f);
                auto slider = OptionSlider::create(sliderW, 28.f, option->mn, option->mx,
                    option->st, option->f, [this, index](float value, bool final) {
                        applyStepValue(index, value, final);
                    });
                slider->setPosition(x + 9.f, y + 3.f);
                addChild(slider, 5);

                auto input = TextInput::create(fieldW, "value", "chatFont.fnt");
                input->setFilter("0123456789.-");
                input->setString(editableValue(*option));
                input->setPosition(x + colW - applyW - fieldW / 2.f - 8.f, y + 18.f);
                addChild(input, 6);
                m_inputs[i] = input;

                auto apply = CCMenuItemSpriteExtra::create(button("Set", applyW, 22.f, false, 0.62f),
                    this, menu_selector(OptionList::onSetValue));
                apply->m_scaleMultiplier = 1.f;
                apply->setTag(index);
                apply->setPosition(x + colW - applyW / 2.f - 7.f, y + 18.f);
                menu->addChild(apply);
                y -= 3.f;
            } else if (option->kind == Kind::Toggle) {
                const float rowH = metrics::rowH;
                y -= rowH;
                const bool locked = option->locked && option->locked();
                auto row = CCNode::create();
                row->setContentSize({colW - 14.f, rowH - 2.f});
                auto box = rect(15.f, 15.f, option->b
                    ? ccc4(theme::accent().r, theme::accent().g, theme::accent().b, 255)
                    : ccc4(theme::muted().r, theme::muted().g, theme::muted().b, 110));
                box->setPosition(0.f, (rowH - 17.f) / 2.f);
                row->addChild(box);
                auto name = label(option->name, metrics::nameScale, locked ? theme::muted() : theme::text(),
                    {0.f, 0.5f}, {23.f, (rowH - 2.f) / 2.f});
                fit(name, colW - 45.f, metrics::nameScale);
                row->addChild(name);
                auto item = CCMenuItemSpriteExtra::create(row, this, menu_selector(OptionList::onToggle));
                item->m_scaleMultiplier = 1.f;
                item->setTag(index);
                item->setEnabled(!locked);
                item->setPosition(x + 8.f + (colW - 14.f) / 2.f, y + rowH / 2.f);
                menu->addChild(item);
            } else {
                const float rowH = metrics::rowH;
                y -= rowH;
                auto action = CCMenuItemSpriteExtra::create(button(option->name.c_str(), colW - 16.f,
                    metrics::actionH, false, metrics::nameScale), this, menu_selector(OptionList::onAction));
                action->m_scaleMultiplier = 1.f;
                action->setTag(index);
                action->setPosition(x + colW / 2.f, y + rowH / 2.f);
                menu->addChild(action);
            }
        }
    }

    if (m_pageCount > 1) {
        auto previous = CCMenuItemSpriteExtra::create(button("<", metrics::pageBtnW, metrics::pageBtnH),
            this, menu_selector(OptionList::onPage));
        previous->m_scaleMultiplier = 1.f;
        previous->setTag(-1);
        previous->setPosition(w - metrics::pageBtnW * 1.5f - 7.f, 14.f);
        previous->setEnabled(m_page > 0);
        menu->addChild(previous);

        auto next = CCMenuItemSpriteExtra::create(button(">", metrics::pageBtnW, metrics::pageBtnH),
            this, menu_selector(OptionList::onPage));
        next->m_scaleMultiplier = 1.f;
        next->setTag(1);
        next->setPosition(w - metrics::pageBtnW / 2.f - 3.f, 14.f);
        next->setEnabled(m_page + 1 < m_pageCount);
        menu->addChild(next);
        addChild(label(fmt::format("{}/{}", m_page + 1, m_pageCount), 0.62f, theme::muted(),
            {1.f, 0.5f}, {w - metrics::pageBtnW * 2.f - 14.f, 14.f}));
    }

    (void)animate;
    return true;
}

void OptionList::applyStepValue(int index, float value, bool persist) {
    if (index < 0 || static_cast<size_t>(index) >= m_opts.size()) return;
    Option* option = m_opts[static_cast<size_t>(index)];
    option->f = normalizeValue(*option, value);
    if (static_cast<size_t>(index) < m_inputs.size() && m_inputs[static_cast<size_t>(index)])
        m_inputs[static_cast<size_t>(index)]->setString(editableValue(*option));
    if (option->onChange) option->onChange();
    if (persist) changed();
    if (m_onSel) m_onSel(option);
}

void OptionList::onToggle(CCObject* sender) {
    const int index = static_cast<CCNode*>(sender)->getTag();
    if (index < 0 || static_cast<size_t>(index) >= m_opts.size()) return;
    Option* option = m_opts[static_cast<size_t>(index)];
    if (option->locked && option->locked()) return;
    option->b = !option->b;
    changed();
    if (option->onChange) option->onChange();
    if (m_onSel) m_onSel(option);
    runAction(CCCallFunc::create(this, callfunc_selector(OptionList::rebuild)));
}

void OptionList::onStep(CCObject* sender) {
    const int tag = static_cast<CCNode*>(sender)->getTag();
    const int index = tag / 2;
    if (index < 0 || static_cast<size_t>(index) >= m_opts.size()) return;
    Option* option = m_opts[static_cast<size_t>(index)];
    applyStepValue(index, option->f + ((tag & 1) ? option->st : -option->st), true);
    runAction(CCCallFunc::create(this, callfunc_selector(OptionList::rebuild)));
}

void OptionList::onSetValue(CCObject* sender) {
    const int index = static_cast<CCNode*>(sender)->getTag();
    if (index < 0 || static_cast<size_t>(index) >= m_opts.size()) return;
    auto* input = m_inputs[static_cast<size_t>(index)];
    if (!input) return;
    try {
        std::string raw = input->getString();
        size_t used = 0;
        float parsed = std::stof(raw, &used);
        if (used != raw.size() || !std::isfinite(parsed)) throw std::invalid_argument("invalid number");
        applyStepValue(index, normalizeValue(*m_opts[static_cast<size_t>(index)], parsed), true);
        input->setString(editableValue(*m_opts[static_cast<size_t>(index)]));
    } catch (...) {
        input->setString(editableValue(*m_opts[static_cast<size_t>(index)]));
    }
}

void OptionList::onAction(CCObject* sender) {
    const int index = static_cast<CCNode*>(sender)->getTag();
    if (index < 0 || static_cast<size_t>(index) >= m_opts.size()) return;
    Option* option = m_opts[static_cast<size_t>(index)];
    if (option->action) option->action();
    if (m_onSel) m_onSel(option);
}

void OptionList::onHelp(CCObject* sender) {
    const int index = static_cast<CCNode*>(sender)->getTag();
    if (index >= 0 && static_cast<size_t>(index) < m_opts.size() && m_onSel)
        m_onSel(m_opts[static_cast<size_t>(index)]);
}

void OptionList::onPage(CCObject* sender) {
    if (m_pageCount <= 1) return;
    int next = std::clamp(m_page + static_cast<CCNode*>(sender)->getTag(), 0, m_pageCount - 1);
    if (next == m_page) return;
    m_page = next;
    runAction(CCCallFunc::create(this, callfunc_selector(OptionList::rebuild)));
}
