#include "Draw.hpp"
#include "UI/Theme.hpp"

namespace scro::draw {
CCLayerColor* rect(float w, float h, ccColor4B c) {
    auto r = CCLayerColor::create(c, w, h);
    r->ignoreAnchorPointForPosition(false);
    r->setAnchorPoint({0.f, 0.f});
    return r;
}

CCLabelBMFont* label(std::string const& t, float scale, ccColor3B col, CCPoint anchor, CCPoint pos) {
    auto l = CCLabelBMFont::create(t.c_str(), theme::font());
    l->setScale(scale * theme::fontScale());
    l->setColor(col);
    l->setAnchorPoint(anchor);
    l->setPosition(pos);
    return l;
}

void fit(CCLabelBMFont* l, float maxWidth, float scale) {
    l->limitLabelWidth(maxWidth, scale * theme::fontScale(), 0.3f);
}

static constexpr int kFadeTag = 0x5C0F;
template <class T> static bool fadeAs(CCNode* n, float delay) {
    if (auto p = typeinfo_cast<T*>(n)) {
        if (n->getActionByTag(kFadeTag)) return true;
        GLubyte opacity = p->getOpacity();
        p->setOpacity(0);
        auto seq = CCSequence::create(CCDelayTime::create(delay), CCFadeTo::create(0.12f, opacity), nullptr);
        seq->setTag(kFadeTag);
        n->runAction(seq);
        return true;
    }
    return false;
}

void fadeTree(CCNode* n, float delay) {
    if (fadeAs<CCLabelBMFont>(n, delay)) return;
    if (!fadeAs<CCLayerColor>(n, delay)) fadeAs<CCSprite>(n, delay);
    if (auto children = n->getChildren())
        for (auto child : CCArrayExt<CCNode*>(children)) fadeTree(child, delay);
}

CCNode* button(char const* text, float w, float h, bool selected, float textScale) {
    auto node = CCNode::create();
    node->setContentSize({w, h});
    auto bg = CCScale9Sprite::create("square02_001.png");
    bg->setContentSize({w, h});
    bg->setPosition({w / 2.f, h / 2.f});
    bg->setColor(selected ? theme::accent() : theme::surface());
    bg->setOpacity(255);
    node->addChild(bg);
    auto caption = label(text, textScale > 0.f ? textScale : 0.78f,
        selected ? theme::selectedText() : theme::text(), {0.5f, 0.5f}, {w / 2.f, h / 2.f});
    fit(caption, w - 10.f, textScale > 0.f ? textScale : 0.78f);
    node->addChild(caption);
    return node;
}

CCScale9Sprite* panel(float w, float h, bool) {
    auto bg = CCScale9Sprite::create("square02_001.png");
    bg->setContentSize({w, h});
    bg->setAnchorPoint({0.f, 0.f});
    bg->setColor(theme::panel());
    bg->setOpacity(255);
    return bg;
}

CCScale9Sprite* inset(float w, float h) {
    auto bg = CCScale9Sprite::create("square02_001.png");
    bg->setContentSize({w, h});
    bg->setAnchorPoint({0.f, 0.f});
    bg->setColor(theme::surface());
    bg->setOpacity(255);
    return bg;
}
}
